<?php 

defined('_JEXEC') or die;

/**
 * File       helper.php
 * Author     Nephi Andersen | support@pcturnaround.com | http://pcturnaround.com
 * Support    https://github.com/link375/
 * Copyright  Copyright (C) 2018 PCTurnaround llc. All Rights Reserved.
 * License    GNU General Public License version 2, or later.
 */
class modJlmsCourseTrackerHelper
{
	public static function getAjax()
	{
		
		$url = $_SERVER['REQUEST_URI'];
		$regex = '/(?P<digit>\d+)/';

		if (preg_match($regex, $url, $matches, PREG_OFFSET_CAPTURE)){
			$courseID = $matches['0'][0];
		}else{
			$courseID = 0;
		}

		$user = JLMSFactory::getUser();
		$userID = $user->id;
		$courseCompleted = false;
		$cert = NULL;
		$steps = array();
		$currentStep = 0;

        $db = JFactory::getDbo();

		/***************FIGURE OUT IF THE USER HAS COMPLETED THE COURSE *********/
		$query = "SELECT crt_date"
		. "\n FROM #__lms_certificate_users"
		. "\n WHERE user_id = " . $db->quote($userID)
		. "\n AND course_id = " . $db->quote($courseID)
		;

		$db->setQuery($query);
		$cert = $db->loadResult();


		/************GET THE LEARNING PATH STEP IDS*********/
		$query = "SELECT id"
		. "\n FROM #__lms_learn_path_steps"
		. "\n WHERE course_id = " . $db->quote($courseID)
		. "\n ORDER BY lpath_id, ordering ASC"
		;

		$db->setQuery($query);
		$steps = $db->loadColumn();

		/***************GET THE CURRENT STEP *************/
		$query = "SELECT last_step_id"
		. "\n FROM #__lms_learn_path_results"
		. "\n WHERE course_id = " . $db->quote($courseID)
		. "\n AND user_id = " . $db->quote($userID)
		. "\n AND user_status = 0"
		. "\n ORDER BY lpath_id DESC"
		;

		$db->setQuery($query);
		$currentStep = $db->loadResult();

		if ($currentStep == NULL && $cert == NULL){
			$query = "SELECT MAX(last_step_id)"
			. "\n FROM #__lms_learn_path_results"
			. "\n WHERE course_id = " . $db->quote($courseID)
			. "\n AND user_id = " . $db->quote($userID)
			. "\n AND user_status = 1"
			. "\n ORDER BY lpath_id DESC"
			;

			$db->setQuery($query);
			$currentStep = $db->loadResult();
		}
		elseif ($currentStep == 0 && $cert == NULL){
			$query = "SELECT MAX(last_step_id)"
			. "\n FROM #__lms_learn_path_results"
			. "\n WHERE course_id = " . $db->quote($courseID)
			. "\n AND user_id = " . $db->quote($userID)
			. "\n AND user_status = 0"
			. "\n ORDER BY lpath_id ASC"
			;

			$db->setQuery($query);
			$currentStep = $db->loadResult();
			
			if ($currentStep == 0){
				 $query = "SELECT MAX(last_step_id)"
				. "\n FROM #__lms_learn_path_results"
				. "\n WHERE course_id = " . $db->quote($courseID)
				. "\n AND user_id = " . $db->quote($userID)
				. "\n AND user_status = 1"
				. "\n ORDER BY lpath_id DESC"
				;

				$db->setQuery($query);
				$currentStep = $db->loadResult();
			}	
		}

		/***SET THE VALUE OF THE PROGRESS BAR TO THE LAST STEP ID IF THE COURSE IS COMPLETED *******/
		if($cert != NULL){
			$courseCompleted = true;
			$currentStep = end($steps);
		}
		elseif ($cert == NULL){
			$courseCompleted = false;
		}

		/***************PREPARE DATA TO PASS TO HTML***********/
		$total = count($steps, COUNT_RECURSIVE)-1;
		$current = array_search($currentStep, $steps);
		$percent = round(($current/$total) * 100);

		/****SPECIAL CASES****/

		/***** USER IS ON THE LAST STEP AND DOES NOT HAVE A CERTIFICATE YET SET TO 99% *****/
		if (($cert == NULL && $currentStep == end($steps)) || 
			($percent == 100 && $cert == NULL)){
			$total = 100;
			$current = 99;
			$percent = 99;
		}
		
		/**** IF THERE IS ONLY ONE STEP THE INDEX WILL BE 0 FOR THE STEPS ARRAY*********/
		if (is_nan($percent) && 
			$currentStep != NULL && 
			$currentStep == $steps[0] && 
			$cert != NULL){
			$percent = 100;
			$current = 1;
			$total = 1;
		}

		/****  USER HASN'T STARTED THE COURSE YET *******/
		if ($currentStep == NULL &&
			$courseCompleted == false){
			$percent = 0;
			$current = 0;
			$total = 100;
		}

		/** JSON ENCODING TO PASS TO AJAX REQUEST**/
		$progressBarValues = array(
			'total' => $total,
			'current' => $current,
			'percent' => $percent,
			'userID' => $userID,
 		    'courseID' => $courseID,
		);

		$results = json_encode($progressBarValues);
		return $results;
	}
}
